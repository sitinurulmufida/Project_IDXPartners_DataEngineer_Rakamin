
SELECT * FROM FactSalesOrder;
