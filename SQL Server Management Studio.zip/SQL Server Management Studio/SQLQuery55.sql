
SELECT * FROM DimStatusOrder;
