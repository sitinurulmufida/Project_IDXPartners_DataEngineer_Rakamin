USE DWH_Project

-- Tabel DimCustomer
CREATE TABLE DimCustomer (
    CustomerID INT PRIMARY KEY NOT NULL,
    CustomerName VARCHAR(50) NOT NULL,
	Age INT NOT NULL,
	Gender VARCHAR (50) NOT NULL,
	City VARCHAR (50) NOT NULL,
	NoHP VARCHAR (50) NOT NULL);

-- Tabel DimProduct
CREATE TABLE DimProduct (
	ProductID INT PRIMARY KEY NOT NULL,
	ProductName VARCHAR (255) NOT NULL,
	ProductCategory VARCHAR(255) NOT NULL,
	ProductUnitPrice INT NOT NULL);

-- Tabel DimStatusOrder
CREATE TABLE DimStatusOrder (
    StatusID INT PRIMARY KEY NOT NULL,
	StatusOrder VARCHAR(50) NOT NULL, 
	StatusOrderDesc VARCHAR(50) NOT NULL);

-- Tabel FactSalesOrder
CREATE TABLE FactSalesOrder (
	OrderID INT PRIMARY KEY NOT NULL,
	CustomerID INT NOT NULL,
	ProductID INT NOT NULL, 
	Quantity INT NOT NULL,
	Amount INT NOT NULL,
	StatusID INT NOT NULL, 
	OrderDate DATE NOT NULL);
