
SELECT * FROM DimCustomer;
