EXEC summary_order_status @StatusID = 1;
EXEC summary_order_status @StatusID = 2;
EXEC summary_order_status @StatusID = 3;
EXEC summary_order_status @StatusID = 4;