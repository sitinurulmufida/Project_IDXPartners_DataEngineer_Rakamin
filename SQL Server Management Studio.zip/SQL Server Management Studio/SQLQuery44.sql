
SELECT * FROM DimProduct;
